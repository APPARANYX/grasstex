# 100-battle headless benchmark

- Commit: `f89939f2f6e8ff21063d1b24c28a8ab73fe9d2e9`
- Build: `v460`
- Policy: stashed-defaults, revision 0
- Completed: **5/5** in **25.23s** (23.8× real-time, 11.89 battles/min)
- Results: US **5** (100.0%), GER **0** (0.0%), draw/none **0** (0.0%)
- Time-limit battles: **5/5**; captures avg **0** of **4.6** objectives; no-capture **5**
- Objectives nobody ever owned: **8** (34.8%) · never even contested **7** · distinct objectives assigned per side US **3**, GER **2.35**
- No objective progress: longest **117.5s** · mean per battle **115s**
- First contact avg **98.4s** · first fire **96.5s** · first objective progress **2.5s** · first capture **0s**
- Health: **83.2/100 overall** · strategic 98.4 · movement 99.7 · cohesion 89.2 · combat 99 · objective 29.4
- Squad performance: mean **95/100** · median **94.7** · p10 **91.5** · below 60 **0/50** · mission 93.3 · movement 100 · control 99.6 · cohesion 87.2 · combat 69.3 · preservation 98.8
- Stalls: vacant objective **0** · route **0** · soldier movement **0** · targetless command **0** · long regroup **0**
- Coordination: writer conflicts **0** (0 strategic) · loop alerts **2** · idle-under-orders 0.7% · over-cohesion 19.7%
- Combat: **28** discharges · **22** direct · **14** hits (63.6%) · **0** trigger-time LOS blocks · **0** held over a crest
- Stress (5 battles, 59864.7 man-seconds): steady **99.8%** · shaken **0.1%** · rattled **0.1%** · broken **0.0%** · battles reaching shaken/rattled/broken **2/2/0** · men by peak band 486/10/4/0 · shocks **33** · hesitations **0**
- Men whose squad is in contact (1059.1 man-seconds): steady **94.2%** · shaken **4.5%** · rattled **1.3%** · broken **0.0%**
- Squads at mean stress ≥ 0.333: **1** of 50 squad-battles, **3.9** squad-seconds, 1 entries, in **1/5** battles · with 3+ living men: **1** squad-battles, **3.9** squad-seconds, 1 entries, in **1/5** battles · peak squad mean 0.397
- Soldier levers, decisions changed (by band steady/shaken/rattled/broken): react **9** of 34 (26.5%) [7/2/0/0] · aim **10** of 22 (45.5%) [6/4/0/0] · hesitate **0** [0/0/0/0], 0 lapsed · shock **81** blocked [71/10/0/0] (fire 1, suppress 0, bound 0, advance 80)
- Stress memory (lasting,floor,relief): held 530.6 man-seconds · floors 5 men (highest 0.699) · relief kill 6 (0.26) · objective 4 (0.59) · cover 0 (0) · survived 20 (1.03)
- Stress reactions: cower 4 (13.4 s) · flee 0 (0 s) · freeze 0 (0 s) · rage 0 (0 s) · charge blows 0 struck, 0 landed 
- Per battle (p50 / p90 / max): shaken-or-worse man-time 0% / 0.41% / 0.46% · squad-seconds over 0 / 2.34 / 3.9 · shocks 0 / 17.4 / 21
- Runtime: **0 probable JS/runtime errors** · **676 asset/CORS noise** · 4 warnings

## Most problematic runs

| Seed | Winner | Health | Captures | Never owned | Spread us/ge | Route stalls | Move stalls | Targetless | Vacant | Regroup | Conflicts | Loops | Max no-progress |
|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-us-defend-0002` | us | 81.7 | 0/4 | 1 | 3/2.94 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 117.5s |
| `runtime-audit-us-defend-0001` | us | 82.5 | 0/5 | 2 | 3/2.94 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 105s |
| `runtime-audit-us-defend-0004` | us | 83.7 | 0/5 | 2 | 3/1.96 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-us-defend-0005` | us | 83.9 | 0/5 | 2 | 3/1.96 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-us-defend-0003` | us | 84 | 0/4 | 1 | 3/1.96 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |

## Lowest squad performance

| Seed | Squad | Role | Overall | Mission | Movement | Control | Cohesion | Combat | Preservation |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-us-defend-0002` | ge/ge-3 | center | 86.2 | 84.4 | 100 | 82 | 78.5 | 77.5 | 100 |
| `runtime-audit-us-defend-0003` | ge/ge-1 | center | 89 | 84.4 | 100 | 100 | 65.2 | - | 100 |
| `runtime-audit-us-defend-0002` | ge/ge-1 | center | 91 | 84.4 | 100 | 100 | 77.1 | - | 100 |
| `runtime-audit-us-defend-0001` | ge/ge-1 | center | 91.3 | 84.4 | 100 | 100 | 78.8 | - | 100 |
| `runtime-audit-us-defend-0004` | ge/ge-1 | center | 91.3 | 84.4 | 100 | 100 | 78.8 | - | 100 |
| `runtime-audit-us-defend-0005` | ge/ge-0 | left | 91.5 | 84.4 | 100 | 100 | 80.1 | - | 100 |
| `runtime-audit-us-defend-0003` | ge/ge-3 | center | 91.7 | 84.4 | 100 | 100 | 81.4 | - | 100 |
| `runtime-audit-us-defend-0003` | ge/ge-4 | center | 91.7 | 84.4 | 100 | 100 | 81.4 | - | 100 |

## Diagnostic score note

Health and squad-performance scores are transparent triage aids, not pass/fail gates. Squad performance is role-aware: maneuver squads are judged on mission progress without penalizing support/reserve/garrison squads for holding still; combat is omitted when a squad had no combat opportunity. Raw measurements remain authoritative.
