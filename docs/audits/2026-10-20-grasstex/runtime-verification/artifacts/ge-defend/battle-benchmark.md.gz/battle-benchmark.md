# 100-battle headless benchmark

- Commit: `f89939f2f6e8ff21063d1b24c28a8ab73fe9d2e9`
- Build: `v460`
- Policy: stashed-defaults, revision 0
- Completed: **5/5** in **25.42s** (23.6× real-time, 11.8 battles/min)
- Results: US **0** (0.0%), GER **5** (100.0%), draw/none **0** (0.0%)
- Time-limit battles: **5/5**; captures avg **0.2** of **4.2** objectives; no-capture **4**
- Objectives nobody ever owned: **6** (28.6%) · never even contested **6** · distinct objectives assigned per side US **2.74**, GER **2.8**
- No objective progress: longest **117.5s** · mean per battle **111.5s**
- First contact avg **105.1s** · first fire **105.9s** · first objective progress **2.5s** · first capture **105s**
- Health: **84.8/100 overall** · strategic 99.2 · movement 99.8 · cohesion 89.4 · combat 98.6 · objective 37
- Squad performance: mean **95.1/100** · median **93.7** · p10 **91.7** · below 60 **0/50** · mission 93.3 · movement 100 · control 99.8 · cohesion 87.4 · combat 74.4 · preservation 98.6
- Stalls: vacant objective **0** · route **0** · soldier movement **0** · targetless command **0** · long regroup **0**
- Coordination: writer conflicts **0** (0 strategic) · loop alerts **1** · idle-under-orders 0.5% · over-cohesion 19.3%
- Combat: **47** discharges · **19** direct · **13** hits (68.4%) · **0** trigger-time LOS blocks · **33** held over a crest
- Stress (5 battles, 59845.1 man-seconds): steady **99.8%** · shaken **0.1%** · rattled **0.1%** · broken **0.0%** · battles reaching shaken/rattled/broken **2/1/1** · men by peak band 490/3/2/5 · shocks **17** · hesitations **0**
- Men whose squad is in contact (811.1 man-seconds): steady **89.3%** · shaken **6.3%** · rattled **3.1%** · broken **1.3%**
- Squads at mean stress ≥ 0.333: **1** of 50 squad-battles, **15** squad-seconds, 2 entries, in **1/5** battles · with 3+ living men: **1** squad-battles, **15** squad-seconds, 2 entries, in **1/5** battles · peak squad mean 0.879
- Soldier levers, decisions changed (by band steady/shaken/rattled/broken): react **24** of 49 (49.0%) [23/0/1/0] · aim **10** of 19 (52.6%) [9/1/0/0] · hesitate **0** [0/0/0/0], 0 lapsed · shock **33** blocked [0/33/0/0] (fire 2, suppress 4, bound 0, advance 27)
- Stress memory (lasting,floor,relief): held 606 man-seconds · floors 6 men (highest 0.827) · relief kill 7 (0.33) · objective 15 (1.99) · cover 0 (0) · survived 32 (1.53)
- Stress reactions: cower 5 (18.8 s) · flee 0 (0 s) · freeze 2 (6.5 s) · rage 0 (0 s) · charge blows 0 struck, 0 landed 
- Per battle (p50 / p90 / max): shaken-or-worse man-time 0% / 0.47% / 0.74% · squad-seconds over 0 / 9 / 15 · shocks 0 / 9.8 / 15
- Runtime: **0 probable JS/runtime errors** · **676 asset/CORS noise** · 4 warnings

## Most problematic runs

| Seed | Winner | Health | Captures | Never owned | Spread us/ge | Route stalls | Move stalls | Targetless | Vacant | Regroup | Conflicts | Loops | Max no-progress |
|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-ge-defend-0002` | ge | 81.8 | 0/4 | 2 | 2.94/2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-ge-defend-0001` | ge | 83.7 | 0/4 | 1 | 1.96/3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-ge-defend-0003` | ge | 84.2 | 0/4 | 1 | 2.94/3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-ge-defend-0004` | ge | 85.1 | 0/4 | 1 | 2.94/3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 117.5s |
| `runtime-audit-ge-defend-0005` | ge | 89.1 | 1/5 | 1 | 2.94/3 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 87.5s |

## Lowest squad performance

| Seed | Squad | Role | Overall | Mission | Movement | Control | Cohesion | Combat | Preservation |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-ge-defend-0005` | us/us-3 | center | 88.5 | 81.4 | 100 | 97 | 72.1 | - | 100 |
| `runtime-audit-ge-defend-0005` | us/us-2 | support | 89.4 | 97.7 | 100 | 91 | 82.8 | 75 | 40 |
| `runtime-audit-ge-defend-0005` | us/us-1 | center | 89.8 | 84.4 | 100 | 100 | 93.4 | 55 | 100 |
| `runtime-audit-ge-defend-0002` | us/us-3 | center | 90.8 | 84.4 | 100 | 100 | 76.1 | - | 100 |
| `runtime-audit-ge-defend-0004` | us/us-0 | left | 91.3 | 84.4 | 100 | 100 | 78.8 | - | 100 |
| `runtime-audit-ge-defend-0001` | us/us-0 | left | 91.7 | 84.4 | 100 | 100 | 81.4 | - | 100 |
| `runtime-audit-ge-defend-0002` | us/us-2 | support | 91.8 | 95 | 100 | 100 | 78.8 | 65 | 100 |
| `runtime-audit-ge-defend-0003` | us/us-0 | left | 92.1 | 84.4 | 100 | 100 | 84.1 | - | 100 |

## Diagnostic score note

Health and squad-performance scores are transparent triage aids, not pass/fail gates. Squad performance is role-aware: maneuver squads are judged on mission progress without penalizing support/reserve/garrison squads for holding still; combat is omitted when a squad had no combat opportunity. Raw measurements remain authoritative.
