# 100-battle headless benchmark

- Commit: `f89939f2f6e8ff21063d1b24c28a8ab73fe9d2e9`
- Build: `v460`
- Policy: stashed-defaults, revision 0
- Completed: **1/1** in **19.25s** (27.8× real-time, 3.12 battles/min)
- Results: US **0** (0.0%), GER **1** (100.0%), draw/none **0** (0.0%)
- Time-limit battles: **0/1**; captures avg **7** of **6** objectives; no-capture **0**
- Objectives nobody ever owned: **0** (0.0%) · never even contested **0** · distinct objectives assigned per side US **2.22**, GER **2.34**
- No objective progress: longest **122.6s** · mean per battle **122.6s**
- First contact avg **155.1s** · first fire **166.7s** · first objective progress **122.6s** · first capture **130.1s**
- Health: **82.4/100 overall** · strategic 75 · movement 99.4 · cohesion 88.3 · combat 98.3 · objective 50.8
- Squad performance: mean **82.7/100** · median **82.7** · p10 **74** · below 60 **0/13** · mission 72.7 · movement 99.8 · control 91 · cohesion 88.1 · combat 70.2 · preservation 50
- Stalls: vacant objective **4** · route **0** · soldier movement **0** · targetless command **0** · long regroup **0**
- Coordination: writer conflicts **0** (0 strategic) · loop alerts **8** · idle-under-orders 1.6% · over-cohesion 21.3%
- Combat: **279** discharges · **138** direct · **68** hits (49.3%) · **0** trigger-time LOS blocks · **62** held over a crest
- Stress (1 battles, 45403.3 man-seconds): steady **94.5%** · shaken **1.9%** · rattled **2.4%** · broken **1.1%** · battles reaching shaken/rattled/broken **1/1/1** · men by peak band 56/11/11/22 · shocks **55** · hesitations **0**
- Men whose squad is in contact (3966.3 man-seconds): steady **85.3%** · shaken **4.9%** · rattled **5.0%** · broken **4.9%**
- Squads at mean stress ≥ 0.333: **8** of 13 squad-battles, **399** squad-seconds, 9 entries, in **1/1** battles · with 3+ living men: **5** squad-battles, **240** squad-seconds, 6 entries, in **1/1** battles · peak squad mean 1
- Soldier levers, decisions changed (by band steady/shaken/rattled/broken): react **85** of 195 (43.6%) [80/3/2/0] · aim **101** of 138 (73.2%) [73/26/2/0] · hesitate **0** of 2 (0.0%) [0/0/0/0], 0 lapsed · shock **122** blocked [48/66/8/0] (fire 0, suppress 0, bound 0, advance 122)
- Stress memory (lasting,floor,relief): held 3544.2 man-seconds · floors 26 men (highest 0.9) · relief kill 34 (0.93) · objective 64 (0.08) · cover 1 (0.06) · survived 122 (6.25)
- Stress reactions: cower 22 (49.2 s) · flee 4 (289.6 s) · freeze 12 (116.1 s) · rage 0 (0 s) · charge blows 0 struck, 0 landed 
- Per battle (p50 / p90 / max): shaken-or-worse man-time 5.47% / 5.47% / 5.47% · squad-seconds over 399 / 399 / 399 · shocks 55 / 55 / 55
- Runtime: **0 probable JS/runtime errors** · **675 asset/CORS noise** · 4 warnings

## Most problematic runs

| Seed | Winner | Health | Captures | Never owned | Spread us/ge | Route stalls | Move stalls | Targetless | Vacant | Regroup | Conflicts | Loops | Max no-progress |
|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-endurance-0001` | ge | 82.4 | 7/6 | 0 | 2.22/2.34 | 0 | 0 | 0 | 4 | 0 | 0 | 8 | 122.6s |

## Lowest squad performance

| Seed | Squad | Role | Overall | Mission | Movement | Control | Cohesion | Combat | Preservation |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| `runtime-audit-endurance-0001` | us/us-0-fled-3 | maneuver | 74 | 45 | 100 | 100 | 100 | 55 | 0 |
| `runtime-audit-endurance-0001` | us/us-1-fled-13 | maneuver | 74 | 45 | 100 | 100 | 100 | 55 | 0 |
| `runtime-audit-endurance-0001` | us/us-2-fled-25 | maneuver | 74 | 45 | 100 | 100 | 100 | 55 | 0 |
| `runtime-audit-endurance-0001` | us/us-0 | left | 82.2 | 81.8 | 99.8 | 79 | 71.8 | 85.8 | 50 |
| `runtime-audit-endurance-0001` | ge/ge-4 | center | 82.3 | 82.3 | 99.5 | 61 | 90.5 | 74.1 | 90 |
| `runtime-audit-endurance-0001` | us/us-1 | center | 82.6 | 78.7 | 99.6 | 94 | 95.2 | 55 | 10 |
| `runtime-audit-endurance-0001` | us/us-3 | center | 82.7 | 82.4 | 99.8 | 97 | 67.3 | 55 | 60 |
| `runtime-audit-endurance-0001` | ge/ge-2 | support | 84.7 | 81 | 100 | 82 | 66.8 | 90.1 | 100 |

## Diagnostic score note

Health and squad-performance scores are transparent triage aids, not pass/fail gates. Squad performance is role-aware: maneuver squads are judged on mission progress without penalizing support/reserve/garrison squads for holding still; combat is omitted when a squad had no combat opportunity. Raw measurements remain authoritative.
